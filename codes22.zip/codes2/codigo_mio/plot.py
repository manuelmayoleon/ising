#plot.py 
import pandas as pd 
import numpy as np 
import scipy.stats as ss 
import math 
import matplotlib.mlab as mlab 
import matplotlib.pyplot as plt 
from scipy import optimize 

df=pd.read_csv('fort.66',delimiter='\n')
print(df)
L=np.sqrt(len(df))
print(L)

