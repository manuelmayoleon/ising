#plot.py 
import pandas as pd 
import numpy as np 
import scipy.stats as ss 
import math 
import matplotlib.mlab as mlab 
import matplotlib.pyplot as plt 
from scipy import optimize 

# df=pd.read_csv('fort16.66')
# print(df)
data = np.genfromtxt("fort16.66", names=["x", "y"])
def m0teo(x):
    return np.power((1.000-np.power(np.sinh(2.000/x),-4.000)),0.125)         
t=np.linspace(0.01,2.24,1000)
# print(t)
# print(m0teo(t))
print(sum(data['y']))
# plt.subplot(1, 2, 1)
plt.plot(data['x'], data['y'],'bo')

# plt.plot(t,m0teo(t))
 
plt.show()
# L=np.sqrt(len(df))
# print(L)

