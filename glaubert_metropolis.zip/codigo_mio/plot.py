#plot.py 
import pandas as pd 
import numpy as np 
import scipy.stats as ss 
import math 
import matplotlib.mlab as mlab 
import matplotlib.pyplot as plt 
from scipy import optimize 
import random

# df=pd.read_csv('fort16.66')
# print(df)
data = np.genfromtxt("fort216.66", names=["T", "m0","error",\
    "chi","errorchi","Uspin","errorE","cv","errorcv","cbinder"])
data2 = np.genfromtxt("fortglau216.66", names=["T", "m0","error",\
    "chi","errorchi","Uspin","errorE","cv","errorcv","cbinder"])
data32 = np.genfromtxt("fort232.66", names=["T", "m0","error",\
    "chi","errorchi","Uspin","errorE","cv","errorcv","cbinder"])
data232 = np.genfromtxt("fortglau232.66", names=["T", "m0","error",\
    "chi","errorchi","Uspin","errorE","cv","errorcv","cbinder"])      
data64 = np.genfromtxt("fort264.66", names=["T", "m0","error",\
    "chi","errorchi","Uspin","errorE","cv","errorcv","cbinder"])
data264 = np.genfromtxt("fortglau264.66", names=["T", "m0","error",\
    "chi","errorchi","Uspin","errorE","cv","errorcv","cbinder"])
data128 = np.genfromtxt("fort2128.66", names=["T", "m0","error",\
    "chi","errorchi","Uspin","errorE","cv","errorcv","cbinder"])
data2128 = np.genfromtxt("fortglau2128.66", names=["T", "m0","error",\
    "chi","errorchi","Uspin","errorE","cv","errorcv","cbinder"])             
def m0teo(x):
    return np.power((1.000-np.power(np.sinh(2.000/x),-4.000)),0.125)         
t=np.linspace(0.01,2.26,1000)
# print(t)
# print(m0teo(t))
# plt.subplot(1, 2, 1)
plt.figure()
plt.errorbar(data['T'], data['m0'],yerr=data['error'],fmt='bo',markersize=1,capsize=2,elinewidth=2,label="L=16(Metropolis)")
plt.errorbar(data2['T'], data2['m0'],yerr=data2['error'],fmt='o',markersize=1,color='g',capsize=2,elinewidth=2,label="L=16(Glaubert)")
plt.errorbar(data32['T'], data32['m0'],yerr=data32['error'],fmt='o',color='y',markersize=1,capsize=2,elinewidth=2,label="L=32(Metropolis)")
plt.errorbar(data232['T'], data232['m0'],yerr=data232['error'],fmt='o',markersize=1,color='r',capsize=2,elinewidth=2,label="L=32(Glaubert)")
plt.errorbar(data64['T'], data64['m0'],yerr=data64['error'],fmt='o',color='tab:purple',markersize=1,capsize=2,elinewidth=2,label="L=64(Metropolis)")
plt.errorbar(data264['T'], data264['m0'],yerr=data264['error'],fmt='o',markersize=1,color='tab:orange',capsize=2,elinewidth=2,label="L=64(Glaubert)")
# rgb = (round(random.random(),1),round( random.random(),1),round( random.random(),1),round( random.random(),1))
plt.errorbar(data128['T'], data128['m0'],yerr=data128['error'],fmt='o',\
c='C9',markersize=1,capsize=2,elinewidth=2,label="L=128(Metropolis)")
# rgb = (round(random.random(),1),round( random.random(),1),round( random.random(),1),round( random.random(),1))
# print(rgb)
plt.errorbar(data264['T'], data2128['m0'],yerr=data2128['error'],fmt='o',markersize=1,\
c='C10',capsize=2,elinewidth=2,label="L=128(Glaubert)")
plt.plot(t,m0teo(t),label="m0 teorico", linestyle='--')
plt.grid(color='k', linestyle='--', linewidth=0.5,alpha=0.4)
plt.xlim(1.4,3.2)
plt.legend()

plt.figure()
plt.errorbar(data['T'], data['chi'],yerr=data['errorchi'],fmt='bo',markersize=2,capsize=2,elinewidth=1,alpha=0.8,label="Metropolis")
plt.errorbar(data2['T'], data2['chi'],yerr=data2['errorchi'],fmt='o',markersize=2,color='g',capsize=2,elinewidth=0.5,label="Glaubert")
plt.grid(color='k', linestyle='--', linewidth=0.5,alpha=0.4)
plt.legend()
plt.figure()
plt.errorbar(data['T'], data['cv'],yerr=data['errorcv'],fmt='bo',markersize=2,capsize=2,elinewidth=1,alpha=0.8,label="Metropolis")
plt.errorbar(data2['T'], data2['cv'],yerr=data2['errorcv'],fmt='o',markersize=2,color='g',capsize=2,elinewidth=0.5,label="Glaubert")
plt.grid(color='k', linestyle='--', linewidth=0.5,alpha=0.4) 
plt.legend()
plt.figure()
plt.errorbar(data32['T'], data32['chi'],yerr=data32['errorchi'],fmt='bo',markersize=2,capsize=2,elinewidth=1,alpha=0.8,label="Metropolis")
plt.errorbar(data232['T'], data232['chi'],yerr=data232['errorchi'],fmt='o',markersize=2,color='g',capsize=2,elinewidth=0.5,label="Glaubert")
plt.grid(color='k', linestyle='--', linewidth=0.5,alpha=0.4)
plt.legend()
plt.figure()
plt.errorbar(data32['T'], data32['cv'],yerr=data32['errorcv'],fmt='bo',markersize=2,capsize=2,elinewidth=1,alpha=0.8,label="Metropolis")
plt.errorbar(data232['T'], data232['cv'],yerr=data232['errorcv'],fmt='o',markersize=2,color='g',capsize=2,elinewidth=0.5,label="Glaubert")
plt.grid(color='k', linestyle='--', linewidth=0.5,alpha=0.4) 
plt.legend()


plt.figure()
plt.errorbar(data64['T'], data64['chi'],yerr=data64['errorchi'],fmt='bo',markersize=2,capsize=2,elinewidth=1,alpha=0.8,label="Metropolis")
plt.errorbar(data264['T'], data264['chi'],yerr=data264['errorchi'],fmt='o',markersize=2,color='g',capsize=2,elinewidth=0.5,label="Glaubert")
plt.grid(color='k', linestyle='--', linewidth=0.5,alpha=0.4)
plt.legend()
plt.figure()
plt.errorbar(data64['T'], data64['cv'],yerr=data64['errorcv'],fmt='bo',markersize=2,capsize=2,elinewidth=1,alpha=0.8,label="Metropolis")
plt.errorbar(data264['T'], data264['cv'],yerr=data264['errorcv'],fmt='o',markersize=2,color='g',capsize=2,elinewidth=0.5,label="Glaubert")
plt.grid(color='k', linestyle='--', linewidth=0.5,alpha=0.4) 
plt.legend()


plt.figure()
plt.errorbar(data128['T'], data128['cv'],yerr=data128['errorcv'],fmt='bo',markersize=2,capsize=2,elinewidth=1,alpha=0.8,label="Metropolis")
plt.errorbar(data2128['T'], data2128['cv'],yerr=data2128['errorcv'],fmt='o',markersize=2,color='g',capsize=2,elinewidth=0.5,label="Glaubert")
plt.grid(color='k', linestyle='--', linewidth=0.5,alpha=0.4) 
plt.legend()

plt.figure()
plt.errorbar(data128['T'], data128['chi'],yerr=data128['errorchi'],fmt='bo',markersize=2,capsize=2,elinewidth=1,alpha=0.8,label="Metropolis")
plt.errorbar(data2128['T'], data2128['chi'],yerr=data2128['errorchi'],fmt='o',markersize=2,color='g',capsize=2,elinewidth=0.5,label="Glaubert")
plt.grid(color='k', linestyle='--', linewidth=0.5,alpha=0.4) 
plt.legend()


plt.show()
# L=np.sqrt(len(df))
# print(L)

